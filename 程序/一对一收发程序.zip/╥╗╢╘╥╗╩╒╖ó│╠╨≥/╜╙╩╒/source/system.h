/******************************************/
//
// �ó���������Ƶ��11.0592MHz
//
/******************************************/
#ifndef SYSTEM_H_
#define SYSTEM_H_

#include <stc15wxx.h>
	
#define MAIN_Fosc       11059200UL  //������ʱ��
	
typedef     unsigned char   u8;
typedef     unsigned int    u16;
typedef     unsigned long   u32;

sbit STA_LED = P1^3;

void delay_ms(unsigned char ms);
	
#endif