#ifndef var_h
#define var_h

//------------- define Varables -------------
#define 	ubyte unsigned char
#define 	uword unsigned int
EXTERN ubyte t500ms,t20ms;
EXTERN ubyte Flag;
EXTERN ubyte 	keyValue,keyValueBuf;
EXTERN ubyte 	KeyBuf,KeyTemp,chKeyVal,KeyValue2,KeyValue,KeepKeyCnt;
EXTERN ubyte 	Bright,Contrast;
EXTERN ubyte 	OLEDMode;

#endif