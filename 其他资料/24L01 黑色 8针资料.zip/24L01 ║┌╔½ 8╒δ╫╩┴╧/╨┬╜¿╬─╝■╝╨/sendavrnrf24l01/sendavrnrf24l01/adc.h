/*
**  Header file : adc.h
*/

#ifndef		__ADC__H
#define		__ADC__H

void InitADC( void);
int ReadADC( unsigned char);

#endif

/*
**  End of Header file
*/
