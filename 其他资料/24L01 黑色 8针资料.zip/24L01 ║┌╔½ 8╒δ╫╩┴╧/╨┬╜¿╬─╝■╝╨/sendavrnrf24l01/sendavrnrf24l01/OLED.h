#ifndef oled_h
#define oled_h
ubyte ReadOLED(ubyte address);
void WriteMode(void);
void WriteBright(void);


#endif
